﻿namespace romanNumeralConverter
{
    partial class romanNumeralConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oneRadioButton = new System.Windows.Forms.RadioButton();
            this.twoRadioButton = new System.Windows.Forms.RadioButton();
            this.threeRadioButton = new System.Windows.Forms.RadioButton();
            this.fourRadioButton = new System.Windows.Forms.RadioButton();
            this.fiveRadioButton = new System.Windows.Forms.RadioButton();
            this.sixRadioButton = new System.Windows.Forms.RadioButton();
            this.sevenRadioButton = new System.Windows.Forms.RadioButton();
            this.eightRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tenRadioButton = new System.Windows.Forms.RadioButton();
            this.nineRadioButton = new System.Windows.Forms.RadioButton();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.romanNumeralPictureBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.romanNumeralPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // oneRadioButton
            // 
            this.oneRadioButton.AutoSize = true;
            this.oneRadioButton.Location = new System.Drawing.Point(14, 19);
            this.oneRadioButton.Name = "oneRadioButton";
            this.oneRadioButton.Size = new System.Drawing.Size(31, 17);
            this.oneRadioButton.TabIndex = 0;
            this.oneRadioButton.TabStop = true;
            this.oneRadioButton.Text = "1";
            this.oneRadioButton.UseVisualStyleBackColor = true;
            this.oneRadioButton.CheckedChanged += new System.EventHandler(this.oneRadioButton_CheckedChanged);
            // 
            // twoRadioButton
            // 
            this.twoRadioButton.AutoSize = true;
            this.twoRadioButton.Location = new System.Drawing.Point(14, 42);
            this.twoRadioButton.Name = "twoRadioButton";
            this.twoRadioButton.Size = new System.Drawing.Size(31, 17);
            this.twoRadioButton.TabIndex = 1;
            this.twoRadioButton.TabStop = true;
            this.twoRadioButton.Text = "2";
            this.twoRadioButton.UseVisualStyleBackColor = true;
            this.twoRadioButton.CheckedChanged += new System.EventHandler(this.twoRadioButton_CheckedChanged);
            // 
            // threeRadioButton
            // 
            this.threeRadioButton.AutoSize = true;
            this.threeRadioButton.Location = new System.Drawing.Point(14, 65);
            this.threeRadioButton.Name = "threeRadioButton";
            this.threeRadioButton.Size = new System.Drawing.Size(31, 17);
            this.threeRadioButton.TabIndex = 3;
            this.threeRadioButton.TabStop = true;
            this.threeRadioButton.Text = "3";
            this.threeRadioButton.UseVisualStyleBackColor = true;
            this.threeRadioButton.CheckedChanged += new System.EventHandler(this.threeRadioButton_CheckedChanged);
            // 
            // fourRadioButton
            // 
            this.fourRadioButton.AutoSize = true;
            this.fourRadioButton.Location = new System.Drawing.Point(14, 88);
            this.fourRadioButton.Name = "fourRadioButton";
            this.fourRadioButton.Size = new System.Drawing.Size(31, 17);
            this.fourRadioButton.TabIndex = 2;
            this.fourRadioButton.TabStop = true;
            this.fourRadioButton.Text = "4";
            this.fourRadioButton.UseVisualStyleBackColor = true;
            this.fourRadioButton.CheckedChanged += new System.EventHandler(this.fourRadioButton_CheckedChanged);
            // 
            // fiveRadioButton
            // 
            this.fiveRadioButton.AutoSize = true;
            this.fiveRadioButton.Location = new System.Drawing.Point(14, 111);
            this.fiveRadioButton.Name = "fiveRadioButton";
            this.fiveRadioButton.Size = new System.Drawing.Size(31, 17);
            this.fiveRadioButton.TabIndex = 7;
            this.fiveRadioButton.TabStop = true;
            this.fiveRadioButton.Text = "5";
            this.fiveRadioButton.UseVisualStyleBackColor = true;
            this.fiveRadioButton.CheckedChanged += new System.EventHandler(this.fiveRadioButton_CheckedChanged);
            // 
            // sixRadioButton
            // 
            this.sixRadioButton.AutoSize = true;
            this.sixRadioButton.Location = new System.Drawing.Point(14, 134);
            this.sixRadioButton.Name = "sixRadioButton";
            this.sixRadioButton.Size = new System.Drawing.Size(31, 17);
            this.sixRadioButton.TabIndex = 6;
            this.sixRadioButton.TabStop = true;
            this.sixRadioButton.Text = "6";
            this.sixRadioButton.UseVisualStyleBackColor = true;
            this.sixRadioButton.CheckedChanged += new System.EventHandler(this.sixRadioButton_CheckedChanged);
            // 
            // sevenRadioButton
            // 
            this.sevenRadioButton.AutoSize = true;
            this.sevenRadioButton.Location = new System.Drawing.Point(14, 157);
            this.sevenRadioButton.Name = "sevenRadioButton";
            this.sevenRadioButton.Size = new System.Drawing.Size(31, 17);
            this.sevenRadioButton.TabIndex = 5;
            this.sevenRadioButton.TabStop = true;
            this.sevenRadioButton.Text = "7";
            this.sevenRadioButton.UseVisualStyleBackColor = true;
            this.sevenRadioButton.CheckedChanged += new System.EventHandler(this.sevenRadioButton_CheckedChanged);
            // 
            // eightRadioButton
            // 
            this.eightRadioButton.AutoSize = true;
            this.eightRadioButton.Location = new System.Drawing.Point(14, 180);
            this.eightRadioButton.Name = "eightRadioButton";
            this.eightRadioButton.Size = new System.Drawing.Size(31, 17);
            this.eightRadioButton.TabIndex = 4;
            this.eightRadioButton.TabStop = true;
            this.eightRadioButton.Text = "8";
            this.eightRadioButton.UseVisualStyleBackColor = true;
            this.eightRadioButton.CheckedChanged += new System.EventHandler(this.eightRadioButton_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tenRadioButton);
            this.groupBox1.Controls.Add(this.nineRadioButton);
            this.groupBox1.Controls.Add(this.oneRadioButton);
            this.groupBox1.Controls.Add(this.eightRadioButton);
            this.groupBox1.Controls.Add(this.sevenRadioButton);
            this.groupBox1.Controls.Add(this.sixRadioButton);
            this.groupBox1.Controls.Add(this.fiveRadioButton);
            this.groupBox1.Controls.Add(this.twoRadioButton);
            this.groupBox1.Controls.Add(this.threeRadioButton);
            this.groupBox1.Controls.Add(this.fourRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 57);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(65, 250);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Number";
            // 
            // tenRadioButton
            // 
            this.tenRadioButton.AutoSize = true;
            this.tenRadioButton.Location = new System.Drawing.Point(14, 226);
            this.tenRadioButton.Name = "tenRadioButton";
            this.tenRadioButton.Size = new System.Drawing.Size(37, 17);
            this.tenRadioButton.TabIndex = 9;
            this.tenRadioButton.TabStop = true;
            this.tenRadioButton.Text = "10";
            this.tenRadioButton.UseVisualStyleBackColor = true;
            this.tenRadioButton.CheckedChanged += new System.EventHandler(this.tenRadioButton_CheckedChanged);
            // 
            // nineRadioButton
            // 
            this.nineRadioButton.AutoSize = true;
            this.nineRadioButton.Location = new System.Drawing.Point(14, 203);
            this.nineRadioButton.Name = "nineRadioButton";
            this.nineRadioButton.Size = new System.Drawing.Size(31, 17);
            this.nineRadioButton.TabIndex = 8;
            this.nineRadioButton.TabStop = true;
            this.nineRadioButton.Text = "9";
            this.nineRadioButton.UseVisualStyleBackColor = true;
            this.nineRadioButton.CheckedChanged += new System.EventHandler(this.nineRadioButton_CheckedChanged);
            // 
            // instructionLabel
            // 
            this.instructionLabel.Location = new System.Drawing.Point(25, 16);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(304, 27);
            this.instructionLabel.TabIndex = 9;
            this.instructionLabel.Text = "Select an Integer from the \"Number\" list to display it\'s Roman Numeral equivilent" +
    ".";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // romanNumeralPictureBox
            // 
            this.romanNumeralPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.romanNumeralPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.romanNumeralPictureBox.Location = new System.Drawing.Point(94, 57);
            this.romanNumeralPictureBox.Name = "romanNumeralPictureBox";
            this.romanNumeralPictureBox.Size = new System.Drawing.Size(294, 262);
            this.romanNumeralPictureBox.TabIndex = 10;
            this.romanNumeralPictureBox.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(141, 328);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(88, 21);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // romanNumeralConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 357);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.romanNumeralPictureBox);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.groupBox1);
            this.Name = "romanNumeralConverter";
            this.Text = "Roman Numeral Converter";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.romanNumeralPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton oneRadioButton;
        private System.Windows.Forms.RadioButton twoRadioButton;
        private System.Windows.Forms.RadioButton threeRadioButton;
        private System.Windows.Forms.RadioButton fourRadioButton;
        private System.Windows.Forms.RadioButton fiveRadioButton;
        private System.Windows.Forms.RadioButton sixRadioButton;
        private System.Windows.Forms.RadioButton sevenRadioButton;
        private System.Windows.Forms.RadioButton eightRadioButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton tenRadioButton;
        private System.Windows.Forms.RadioButton nineRadioButton;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.PictureBox romanNumeralPictureBox;
        private System.Windows.Forms.Button exitButton;
    }
}

