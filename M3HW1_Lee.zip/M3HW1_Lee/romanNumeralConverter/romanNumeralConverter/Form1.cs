﻿/**
* 11 MAR 2018
* CSC 153
* Christopher Lee
* Roman Numeral Converter
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace romanNumeralConverter
{
    public partial class romanNumeralConverter : Form
    {
        public romanNumeralConverter()
        {
            InitializeComponent();
        }        
        
        //Radio buttons that change the background property for romanNumeralPictureBox
        private void oneRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (oneRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._1; 
        }

        private void twoRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (twoRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._2;
        }

        private void threeRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (threeRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._3;
        }

        private void fourRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (fourRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._4;
        }

        private void fiveRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (fiveRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._5;
        }

        private void sixRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sixRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._6;
        }

        private void sevenRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sevenRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._7;
        }

        private void eightRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (eightRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._8;
        }

        private void nineRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (nineRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._9;
        }

        private void tenRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (tenRadioButton.Checked) ;
            romanNumeralPictureBox.BackgroundImage = global::romanNumeralConverter.Properties.Resources._10;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
