﻿/**
* 18 Feb 2017
* CSC 153
* Christopher Lee
* Program description
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Christopher_Lee
{
    public partial class nameFormatter : Form
    {
        public nameFormatter()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            //Gets name formats from input then concat / print
            formatSelectLabel.Visible = true;

            format1Button.Visible = true;
            format1Button.Text = prefTitleTextBox.Text + " " +firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            format2Button.Visible = true;
            format2Button.Text = firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            format3Button.Visible = true;
            format3Button.Text = firstNameTextBox.Text + " " + lastNameTextBox.Text;

            format4Button.Visible = true;
            format4Button.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + prefTitleTextBox.Text;

            format5Button.Visible = true;
            format5Button.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text;

            format6Button.Visible = true;
            format6Button.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text;

            format1Button.Focus();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Hide output containers and reset text boxes
            confirmButton.Visible = true;
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            prefTitleTextBox.Text = "";
            entryLabel.Visible = false;
            format1Button.Visible = false;
            format2Button.Visible = false;
            format3Button.Visible = false;
            format4Button.Visible = false;
            format5Button.Visible = false;
            format6Button.Visible = false;
            formatSelectLabel.Visible = false;

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();

        }
        //The following Click evenents write the selected format to a text box
        private void format1Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format1Button.Text;
        }

        private void format2Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format2Button.Text;
        }

        private void format3Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format3Button.Text;
        }

        private void format4Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format4Button.Text;
        }

        private void format5Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format5Button.Text;
        }

        private void format6Button_Click(object sender, EventArgs e)
        {
            entryLabel.Visible = true;
            entryLabel.Text = format6Button.Text;
        }
    }
}
