﻿namespace M3HW1_Christopher_Lee
{
    partial class nameFormatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.prefTitleTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format4Button = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.entryLabel = new System.Windows.Forms.Label();
            this.confirmButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.formatSelectLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(103, 33);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(103, 60);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 1;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(103, 87);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // prefTitleTextBox
            // 
            this.prefTitleTextBox.Location = new System.Drawing.Point(103, 114);
            this.prefTitleTextBox.Name = "prefTitleTextBox";
            this.prefTitleTextBox.Size = new System.Drawing.Size(100, 20);
            this.prefTitleTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Middle Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Preferred Title:";
            // 
            // format1Button
            // 
            this.format1Button.Location = new System.Drawing.Point(20, 177);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(159, 23);
            this.format1Button.TabIndex = 8;
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Visible = false;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(20, 207);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(159, 23);
            this.format2Button.TabIndex = 9;
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Visible = false;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(20, 237);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(159, 23);
            this.format3Button.TabIndex = 10;
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Visible = false;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format4Button
            // 
            this.format4Button.Location = new System.Drawing.Point(20, 267);
            this.format4Button.Name = "format4Button";
            this.format4Button.Size = new System.Drawing.Size(159, 23);
            this.format4Button.TabIndex = 11;
            this.format4Button.UseVisualStyleBackColor = true;
            this.format4Button.Visible = false;
            this.format4Button.Click += new System.EventHandler(this.format4Button_Click);
            // 
            // format5Button
            // 
            this.format5Button.Location = new System.Drawing.Point(20, 297);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(159, 23);
            this.format5Button.TabIndex = 12;
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Visible = false;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // entryLabel
            // 
            this.entryLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.entryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entryLabel.Location = new System.Drawing.Point(192, 228);
            this.entryLabel.Name = "entryLabel";
            this.entryLabel.Size = new System.Drawing.Size(146, 45);
            this.entryLabel.TabIndex = 13;
            this.entryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.entryLabel.Visible = false;
            // 
            // confirmButton
            // 
            this.confirmButton.Location = new System.Drawing.Point(232, 42);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(75, 23);
            this.confirmButton.TabIndex = 14;
            this.confirmButton.Text = "Confirm";
            this.confirmButton.UseVisualStyleBackColor = true;
            this.confirmButton.Click += new System.EventHandler(this.confirmButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(232, 72);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 15;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(232, 102);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // format6Button
            // 
            this.format6Button.Location = new System.Drawing.Point(20, 327);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(159, 23);
            this.format6Button.TabIndex = 13;
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Visible = false;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // formatSelectLabel
            // 
            this.formatSelectLabel.AutoSize = true;
            this.formatSelectLabel.ForeColor = System.Drawing.Color.Red;
            this.formatSelectLabel.Location = new System.Drawing.Point(83, 154);
            this.formatSelectLabel.Name = "formatSelectLabel";
            this.formatSelectLabel.Size = new System.Drawing.Size(174, 13);
            this.formatSelectLabel.TabIndex = 18;
            this.formatSelectLabel.Text = "Please click on the prefered format.";
            this.formatSelectLabel.Visible = false;
            // 
            // nameFormatter
            // 
            this.AcceptButton = this.confirmButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(350, 364);
            this.Controls.Add(this.formatSelectLabel);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.entryLabel);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.prefTitleTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Name = "nameFormatter";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox prefTitleTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format4Button;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Label entryLabel;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button format6Button;
        private System.Windows.Forms.Label formatSelectLabel;
    }
}

