﻿namespace diceSimulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.die2PictureBox = new System.Windows.Forms.PictureBox();
            this.die1PictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // rollButton
            // 
            this.rollButton.Location = new System.Drawing.Point(56, 166);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(107, 57);
            this.rollButton.TabIndex = 2;
            this.rollButton.Text = "Roll the DICE!!";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(189, 166);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(107, 57);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "EXIT";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // die2PictureBox
            // 
            this.die2PictureBox.BackgroundImage = global::diceSimulator.Properties.Resources._1Die;
            this.die2PictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.die2PictureBox.Location = new System.Drawing.Point(189, 16);
            this.die2PictureBox.Name = "die2PictureBox";
            this.die2PictureBox.Size = new System.Drawing.Size(145, 135);
            this.die2PictureBox.TabIndex = 1;
            this.die2PictureBox.TabStop = false;
            // 
            // die1PictureBox
            // 
            this.die1PictureBox.BackgroundImage = global::diceSimulator.Properties.Resources._1Die;
            this.die1PictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.die1PictureBox.Location = new System.Drawing.Point(18, 16);
            this.die1PictureBox.Name = "die1PictureBox";
            this.die1PictureBox.Size = new System.Drawing.Size(145, 135);
            this.die1PictureBox.TabIndex = 0;
            this.die1PictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 238);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.die2PictureBox);
            this.Controls.Add(this.die1PictureBox);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox die1PictureBox;
        private System.Windows.Forms.PictureBox die2PictureBox;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
    }
}

