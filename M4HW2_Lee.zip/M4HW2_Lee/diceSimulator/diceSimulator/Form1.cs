﻿/*
 * 15 MAY 2018
 * CSC 153
 * Christopher Lee
 * Dice Simulator
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace diceSimulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            int leftDie;
            int rightDie;

            Random rand1 = new Random();
            Random rand2 = new Random();

            leftDie = rand1.Next(6) + 1;
            rightDie = rand1.Next(6) + 1;

            switch (leftDie)
            {
                case 1:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._1Die;
                    break;
                case 2:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._2Die;
                    break;
                case 3:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._3Die;
                    break;
                case 4:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._4Die;
                    break;
                case 5:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._5Die;
                    break;
                case 6:
                    die1PictureBox.BackgroundImage = diceSimulator.Properties.Resources._6Die;
                    break;
            }
            switch (rightDie)
            {
                case 1:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._1Die;
                    break;
                case 2:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._2Die;
                    break;
                case 3:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._3Die;
                    break;
                case 4:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._4Die;
                    break;
                case 5:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._5Die;
                    break;
                case 6:
                    die2PictureBox.BackgroundImage = diceSimulator.Properties.Resources._6Die;
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
