﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softwareSales
{
    public partial class softwareSales : Form
    {
        public softwareSales()
        {
            InitializeComponent();
        }

        const double SPROCKET_PRICE = 99;
        int numberOrdered = 0;
        double discountPercentage = 0;
        double discountPrice = 0;
        double totPrice = 0;

        private void calculateButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(purchaseTextBox.Text, out numberOrdered))
            {
                if (numberOrdered < 10) 
                {
                    discountPercentage = 0;
                }
                else if (numberOrdered >= 10 && numberOrdered < 20) 
                {
                    discountPercentage = .20;
                }
                else if (numberOrdered >= 20 && numberOrdered < 50) 
                {
                    discountPercentage = .30;
                }
                else if (numberOrdered >= 50 && numberOrdered < 100) 
                {
                    discountPercentage = .40;
                }
                else if (numberOrdered >= 100)
                {
                    discountPercentage = .50;
                }

                if (numberOrdered < 10)
                {
                    MessageBox.Show("You have not purchased enough Sprockets to recieve a bulk discount. You must order 10 or more to start saving!");
                }
                else
                {
                    MessageBox.Show("Congratulations! You recieved a " + discountPercentage.ToString("p") + " discount on this order.");
                }

                discountPrice = SPROCKET_PRICE - SPROCKET_PRICE * discountPercentage;
                totPrice = discountPrice * numberOrdered;

                discountLabel.Text = discountPercentage.ToString("p");
                ppuLabel.Text = discountPrice.ToString("c");
                totLabel.Text = totPrice.ToString("c");

                purchaseTextBox.Enabled = false;

                calculateButton.Visible = false;
                calculateButton.Enabled = false;

                resetButton.Visible = true;
                resetButton.Enabled = true;

                resetButton.Focus();
            }
            else
            {
                purchaseTextBox.Enabled = true;
                purchaseTextBox.Text = "0";
                purchaseTextBox.Focus();
                MessageBox.Show("Please enter a valid number to continue.");
            }
          
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            discountLabel.Text = "";
            ppuLabel.Text = "";
            totLabel.Text = "";

            purchaseTextBox.Enabled = true;

            calculateButton.Visible = true;
            calculateButton.Enabled = true;

            resetButton.Visible = false;
            resetButton.Enabled = false;

            purchaseTextBox.Text = "0";
            purchaseTextBox.Focus();

            numberOrdered = 0;
            discountPercentage = 0;
            discountPrice = 0;
            totPrice = 0;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
