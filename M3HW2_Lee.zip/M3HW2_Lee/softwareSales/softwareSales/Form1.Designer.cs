﻿namespace softwareSales
{
    partial class softwareSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.purchaseTextBox = new System.Windows.Forms.TextBox();
            this.discountInfoLabel = new System.Windows.Forms.Label();
            this.ppuInfoLabel = new System.Windows.Forms.Label();
            this.totInfoLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.totLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.ppuLabel = new System.Windows.Forms.Label();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // purchaseTextBox
            // 
            this.purchaseTextBox.Location = new System.Drawing.Point(12, 77);
            this.purchaseTextBox.MaxLength = 9;
            this.purchaseTextBox.Name = "purchaseTextBox";
            this.purchaseTextBox.Size = new System.Drawing.Size(127, 20);
            this.purchaseTextBox.TabIndex = 0;
            this.purchaseTextBox.Text = "0";
            // 
            // discountInfoLabel
            // 
            this.discountInfoLabel.AutoSize = true;
            this.discountInfoLabel.Location = new System.Drawing.Point(167, 19);
            this.discountInfoLabel.Name = "discountInfoLabel";
            this.discountInfoLabel.Size = new System.Drawing.Size(52, 13);
            this.discountInfoLabel.TabIndex = 1;
            this.discountInfoLabel.Text = "Discount:";
            // 
            // ppuInfoLabel
            // 
            this.ppuInfoLabel.AutoSize = true;
            this.ppuInfoLabel.Location = new System.Drawing.Point(147, 47);
            this.ppuInfoLabel.Name = "ppuInfoLabel";
            this.ppuInfoLabel.Size = new System.Drawing.Size(72, 13);
            this.ppuInfoLabel.TabIndex = 2;
            this.ppuInfoLabel.Text = "Price per unit:";
            // 
            // totInfoLabel
            // 
            this.totInfoLabel.AutoSize = true;
            this.totInfoLabel.Location = new System.Drawing.Point(161, 79);
            this.totInfoLabel.Name = "totInfoLabel";
            this.totInfoLabel.Size = new System.Drawing.Size(58, 13);
            this.totInfoLabel.TabIndex = 3;
            this.totInfoLabel.Text = "Total Cost:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(225, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(225, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "label5";
            // 
            // totLabel
            // 
            this.totLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totLabel.Location = new System.Drawing.Point(225, 76);
            this.totLabel.Name = "totLabel";
            this.totLabel.Size = new System.Drawing.Size(83, 22);
            this.totLabel.TabIndex = 6;
            this.totLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // discountLabel
            // 
            this.discountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountLabel.Location = new System.Drawing.Point(225, 16);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(83, 22);
            this.discountLabel.TabIndex = 4;
            this.discountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ppuLabel
            // 
            this.ppuLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ppuLabel.Location = new System.Drawing.Point(225, 46);
            this.ppuLabel.Name = "ppuLabel";
            this.ppuLabel.Size = new System.Drawing.Size(83, 22);
            this.ppuLabel.TabIndex = 5;
            this.ppuLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // instructionLabel
            // 
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLabel.Location = new System.Drawing.Point(12, 12);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(129, 56);
            this.instructionLabel.TabIndex = 7;
            this.instructionLabel.Text = "Enter the number of Spacely\'s Spockets you wish to purchase in the box below:";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(12, 112);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(127, 27);
            this.calculateButton.TabIndex = 9;
            this.calculateButton.Text = "Calculate Order";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Enabled = false;
            this.resetButton.Location = new System.Drawing.Point(12, 112);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(127, 27);
            this.resetButton.TabIndex = 10;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Visible = false;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(181, 112);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(127, 27);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // softwareSales
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 151);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.totLabel);
            this.Controls.Add(this.ppuLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.totInfoLabel);
            this.Controls.Add(this.ppuInfoLabel);
            this.Controls.Add(this.discountInfoLabel);
            this.Controls.Add(this.purchaseTextBox);
            this.Name = "softwareSales";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox purchaseTextBox;
        private System.Windows.Forms.Label discountInfoLabel;
        private System.Windows.Forms.Label ppuInfoLabel;
        private System.Windows.Forms.Label totInfoLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label totLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label ppuLabel;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

