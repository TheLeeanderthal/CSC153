﻿namespace M1T1_Lee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayMessageButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // displayMessageButton
            // 
            this.displayMessageButton.Location = new System.Drawing.Point(107, 94);
            this.displayMessageButton.Name = "displayMessageButton";
            this.displayMessageButton.Size = new System.Drawing.Size(75, 42);
            this.displayMessageButton.TabIndex = 0;
            this.displayMessageButton.Text = "Display Message";
            this.displayMessageButton.UseVisualStyleBackColor = true;
            this.displayMessageButton.Click += new System.EventHandler(this.displayMessageButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.displayMessageButton);
            this.Name = "Form1";
            this.Text = "Hello World";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button displayMessageButton;
    }
}

