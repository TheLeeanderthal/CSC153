﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sentenceBuilder
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        //Initialize variable
        string sentence = "";

        //Buttons update variable and print to label
        private void capAButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "A";
            sentenceLabel.Text = sentence;
        }

        private void lowAButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "a";
            sentenceLabel.Text = sentence;
        }

        private void capAnButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "An";
            sentenceLabel.Text = sentence;
        }

        private void lowAnButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "an";
            sentenceLabel.Text = sentence;
        }

        private void capTheButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "The";
            sentenceLabel.Text = sentence;
        }

        private void lowTheButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "the";
            sentenceLabel.Text = sentence;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "man";
            sentenceLabel.Text = sentence;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "woman";
            sentenceLabel.Text = sentence;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "dog";
            sentenceLabel.Text = sentence;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "cat";
            sentenceLabel.Text = sentence;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "car";
            sentenceLabel.Text = sentence;
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "bicycle";
            sentenceLabel.Text = sentence;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "beautiful";
            sentenceLabel.Text = sentence;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "big";
            sentenceLabel.Text = sentence;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "small";
            sentenceLabel.Text = sentence;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "strange";
            sentenceLabel.Text = sentence;
        }

        private void lookedButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "looked at";
            sentenceLabel.Text = sentence;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "rode";
            sentenceLabel.Text = sentence;
        }

        private void spokeButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "spoke to";
            sentenceLabel.Text = sentence;
        }

        private void laughedButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "laughed at";
            sentenceLabel.Text = sentence;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "drove";
            sentenceLabel.Text = sentence;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + " ";
            sentenceLabel.Text = sentence;
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + ".";
            sentenceLabel.Text = sentence;
        }

        private void exclamationButton_Click(object sender, EventArgs e)
        {
            sentence = sentence + "!";
            sentenceLabel.Text = sentence;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            sentence = "";
            sentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
