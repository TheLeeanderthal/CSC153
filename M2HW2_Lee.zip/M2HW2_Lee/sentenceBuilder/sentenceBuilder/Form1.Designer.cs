﻿namespace sentenceBuilder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.capAButton = new System.Windows.Forms.Button();
            this.lowAButton = new System.Windows.Forms.Button();
            this.capAnButton = new System.Windows.Forms.Button();
            this.lowAnButton = new System.Windows.Forms.Button();
            this.capTheButton = new System.Windows.Forms.Button();
            this.lowTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeButton = new System.Windows.Forms.Button();
            this.laughedButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // resetButton
            // 
            this.resetButton.AutoSize = true;
            this.resetButton.Location = new System.Drawing.Point(179, 226);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 0;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(260, 226);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // capAButton
            // 
            this.capAButton.Location = new System.Drawing.Point(26, 33);
            this.capAButton.Name = "capAButton";
            this.capAButton.Size = new System.Drawing.Size(75, 23);
            this.capAButton.TabIndex = 3;
            this.capAButton.Text = "A";
            this.capAButton.UseVisualStyleBackColor = true;
            this.capAButton.Click += new System.EventHandler(this.capAButton_Click);
            // 
            // lowAButton
            // 
            this.lowAButton.Location = new System.Drawing.Point(107, 33);
            this.lowAButton.Name = "lowAButton";
            this.lowAButton.Size = new System.Drawing.Size(75, 23);
            this.lowAButton.TabIndex = 2;
            this.lowAButton.Text = "a";
            this.lowAButton.UseVisualStyleBackColor = true;
            this.lowAButton.Click += new System.EventHandler(this.lowAButton_Click);
            // 
            // capAnButton
            // 
            this.capAnButton.Location = new System.Drawing.Point(188, 33);
            this.capAnButton.Name = "capAnButton";
            this.capAnButton.Size = new System.Drawing.Size(75, 23);
            this.capAnButton.TabIndex = 5;
            this.capAnButton.Text = "An";
            this.capAnButton.UseVisualStyleBackColor = true;
            this.capAnButton.Click += new System.EventHandler(this.capAnButton_Click);
            // 
            // lowAnButton
            // 
            this.lowAnButton.Location = new System.Drawing.Point(269, 33);
            this.lowAnButton.Name = "lowAnButton";
            this.lowAnButton.Size = new System.Drawing.Size(75, 23);
            this.lowAnButton.TabIndex = 4;
            this.lowAnButton.Text = "an";
            this.lowAnButton.UseVisualStyleBackColor = true;
            this.lowAnButton.Click += new System.EventHandler(this.lowAnButton_Click);
            // 
            // capTheButton
            // 
            this.capTheButton.Location = new System.Drawing.Point(350, 33);
            this.capTheButton.Name = "capTheButton";
            this.capTheButton.Size = new System.Drawing.Size(75, 23);
            this.capTheButton.TabIndex = 7;
            this.capTheButton.Text = "The";
            this.capTheButton.UseVisualStyleBackColor = true;
            this.capTheButton.Click += new System.EventHandler(this.capTheButton_Click);
            // 
            // lowTheButton
            // 
            this.lowTheButton.Location = new System.Drawing.Point(431, 33);
            this.lowTheButton.Name = "lowTheButton";
            this.lowTheButton.Size = new System.Drawing.Size(75, 23);
            this.lowTheButton.TabIndex = 6;
            this.lowTheButton.Text = "the";
            this.lowTheButton.UseVisualStyleBackColor = true;
            this.lowTheButton.Click += new System.EventHandler(this.lowTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(26, 62);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(75, 23);
            this.manButton.TabIndex = 13;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(107, 62);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(75, 23);
            this.womanButton.TabIndex = 12;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(188, 62);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(75, 23);
            this.dogButton.TabIndex = 11;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(269, 62);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(75, 23);
            this.catButton.TabIndex = 10;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(350, 62);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(75, 23);
            this.carButton.TabIndex = 9;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(431, 62);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(75, 23);
            this.bicycleButton.TabIndex = 8;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(107, 91);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(75, 23);
            this.beautifulButton.TabIndex = 17;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(188, 91);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(75, 23);
            this.bigButton.TabIndex = 16;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(269, 91);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(75, 23);
            this.smallButton.TabIndex = 15;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(350, 91);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(75, 23);
            this.strangeButton.TabIndex = 14;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedButton
            // 
            this.lookedButton.Location = new System.Drawing.Point(66, 120);
            this.lookedButton.Name = "lookedButton";
            this.lookedButton.Size = new System.Drawing.Size(75, 23);
            this.lookedButton.TabIndex = 21;
            this.lookedButton.Text = "looked at";
            this.lookedButton.UseVisualStyleBackColor = true;
            this.lookedButton.Click += new System.EventHandler(this.lookedButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(147, 120);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(75, 23);
            this.rodeButton.TabIndex = 20;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeButton
            // 
            this.spokeButton.Location = new System.Drawing.Point(228, 120);
            this.spokeButton.Name = "spokeButton";
            this.spokeButton.Size = new System.Drawing.Size(75, 23);
            this.spokeButton.TabIndex = 19;
            this.spokeButton.Text = "spoke to";
            this.spokeButton.UseVisualStyleBackColor = true;
            this.spokeButton.Click += new System.EventHandler(this.spokeButton_Click);
            // 
            // laughedButton
            // 
            this.laughedButton.Location = new System.Drawing.Point(309, 120);
            this.laughedButton.Name = "laughedButton";
            this.laughedButton.Size = new System.Drawing.Size(75, 23);
            this.laughedButton.TabIndex = 18;
            this.laughedButton.Text = "laughed at";
            this.laughedButton.UseVisualStyleBackColor = true;
            this.laughedButton.Click += new System.EventHandler(this.laughedButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(390, 120);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(75, 23);
            this.droveButton.TabIndex = 22;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(147, 149);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(75, 23);
            this.spaceButton.TabIndex = 25;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(228, 149);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(75, 23);
            this.periodButton.TabIndex = 24;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(309, 149);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(75, 23);
            this.exclamationButton.TabIndex = 23;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceLabel.Location = new System.Drawing.Point(26, 183);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(480, 23);
            this.sentenceLabel.TabIndex = 26;
            this.sentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(162, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(228, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Click on the buttons below to build a sentence.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 261);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.lookedButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.spokeButton);
            this.Controls.Add(this.laughedButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.capTheButton);
            this.Controls.Add(this.lowTheButton);
            this.Controls.Add(this.capAnButton);
            this.Controls.Add(this.lowAnButton);
            this.Controls.Add(this.capAButton);
            this.Controls.Add(this.lowAButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button capAButton;
        private System.Windows.Forms.Button lowAButton;
        private System.Windows.Forms.Button capAnButton;
        private System.Windows.Forms.Button lowAnButton;
        private System.Windows.Forms.Button capTheButton;
        private System.Windows.Forms.Button lowTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeButton;
        private System.Windows.Forms.Button laughedButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.Label label2;
    }
}

