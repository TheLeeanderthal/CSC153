﻿/**
* 15 MAY 2018
* CSC 153
* Christopher Lee
* Falling Distance
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FallingDistance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Value returning method to calculate falling distance
        private double FallingDistance(double value)
        {
            // Calculation for distance
            double gravity = 9.80665;
            double time = Math.Pow(value, 2.00);
            double distance = time * gravity * .5;

            return distance;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //declare local variables
            double timeFalling, distanceFallen;

            //Test input
            if (double.TryParse(timeFallingTextBox.Text, out timeFalling))
            {
                //Calls FallingDistance Method passes timeFalling 
                distanceFallen = FallingDistance(timeFalling);

                //Prints output
                distanceFallenLabel.Text = distanceFallen.ToString("F2") + " Meters";
            }
            else
            {
                //Display error
                MessageBox.Show("Please enter a valid number");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Close app
            this.Close();
        }
    }
}
