﻿/*
 * 15 MAY 2018
 * CSC 153
 * Christopher Lee
 * Population Estimator
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace population
{
    public partial class Population : Form
    { 
        public Population()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Initialize variables
            double startPop = 0;
            double dailyAv = 0;
            int numDays = 0;
            double dailyTotal = 0;

            //Test input
            if (double.TryParse(startTextBox.Text, out startPop))
            {
                if(double.TryParse(increaseTextBox.Text, out dailyAv))
                {
                    if(int.TryParse(daysTextBox.Text, out numDays))
                    {
                        //Clear listbox
                        populationListBox.Items.Clear();
                        //Format listbox headers
                        populationListBox.Items.Add("Day                          Approximate Population");

                        //initialize couter variable
                        int counter;
                        
                        //Loop
                        for (counter = 1 ; counter <= numDays; counter += 1)
                        {
                            //Calculations
                            if (counter == 1)
                            {
                                dailyTotal = startPop;
                                populationListBox.Items.Add(counter + "                              " + dailyTotal);
                            }
                            else
                            {
                                dailyTotal = startPop + startPop * (dailyAv * .01);
                                populationListBox.Items.Add(counter + "                              " + dailyTotal);
                                startPop = dailyTotal;
                            }

                        }
                        
                    }
                    //Error messages
                    else
                    {
                        MessageBox.Show("Please enter a valid number for the for the number of days.");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number for the average daily increase of population.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number for the starting population.");
            }

            //MessageBox.Show(dailyTotal.ToString("n"));
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
